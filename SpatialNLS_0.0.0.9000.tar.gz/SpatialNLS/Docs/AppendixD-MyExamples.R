
# APPENDIX D - EXAMPLE D2
d = data.frame("t"  = c(1,2,4,5,8),
               "y"  = c(3.2939, 4.2699, 7.1749, 9.308, 20.259)) %>% as_tibble()


ggplot(data = d, aes(x = t, y = y)) +
  # geom_line() +
  geom_point()

bstart = c(2.50,0.25)
names(bstart) = c("x1","x2")

form = y ~ x1*exp(x2*t)

m = nls(formula = form, data = d, start = bstart)
summary(m)

round(coef(m), 4)

# matches bottom of page 747.
# can't believe the authors referred to the parameters as x1 and x2...

newdat = data.frame("t" = seq(1, 8, length.out = 100))
pred   = predict(m, newdata = newdat)

pred = cbind(pred, newdat)
# d$pred = pred

ggplot() +
  geom_line(data = pred, aes(x = t, y = pred, color = "Predicted")) +
  geom_point(data = d, aes(x = t, y = y,color = "Observed"), size = 2.5)
