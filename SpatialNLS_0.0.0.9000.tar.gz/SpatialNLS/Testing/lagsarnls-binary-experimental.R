#-----------------------------------------------------------------------------#
#
# Author:        Logan Stundal
# Date:          February 03, 2021
# Purpose:       Spatial binary outcome models via nonlinear least squares.
#
#
# Copyright (c): Logan Stundal, 2021
# Email:         stund005@umn.edu
#
#-----------------------------------------------------------------------------#
#
# Notes:
# "This script is a work in progress in that less of it works as you progress
#  through it."

#-----------------------------------------------------------------------------#



#-----------------------------------------------------------------------------#
# ADMINISTRATIVE --------------------------------------------------------------

#---------------------------#
# Clear working environment
#---------------------------#
rm(list = ls())

#---------------------------#
# Load required packages
#---------------------------#
library(texreg)
library(ProbitSpatial)
library(microbenchmark)

#---------------------------#
# Set working directory
#---------------------------#
# setwd()

#---------------------------#
# Load data
#---------------------------#
# source("lagsarnls.R")

bin_sim <- function(sample_size = 500,
                    k           = 2,
                    spatial     = FALSE,
                    type        = "logit",
                    b_true      = c(-1,1,2),
                    e_sd        = 0.3,
                    rho_true    = NULL){

  X = replicate(k, rnorm(sample_size, runif(1,-1,1), sd = runif(1,0.5,2)))
  colnames(X) = sprintf("x%s",1:k)

  X = as.matrix(cbind(1,X))

  e = rnorm(n = sample_size, mean = 0, sd = e_sd)
  z = (X %*% b_true) + e


  if(type == "logit"){
    p = exp(z)/(1+exp(z))
    y = rbinom(n = sample_size, size = 1, prob = p)
  } else{
    p = pnorm(z)
    y = rbinom(sample_size, 1, p)
  }

  d = as.data.frame(cbind(X[,2:ncol(X)],y))
  colnames(d) = c(sprintf("x%s",1:k),"y")
  return(d)
}


#-----------------------------------------------------------------------------#
# NON-SPATIAL: LOGIT AND PROBIT VIA GLM ---------------------------------------
siml <- bin_sim(type = "logit")
simp <- bin_sim(type = "probit")

ml.glm   <- glm(y ~ x1 + x2, data = siml, family = binomial(link = "logit"))
mp.glm   <- glm(y ~ x1 + x2, data = simp, family = binomial(link = "probit"))


#-----------------------------------------------------------------------------#
# NON-SPATIAL: LOGIT AND PROBIT VIA GLM ---------------------------------------

ffl    <- y ~ exp(b0 + (b1 * x1) + (b2 * x2)) / (1 + exp(b0 + (b1 * x1) + (b2 * x2)))
ffp    <- y ~ pnorm(b0 + (b1 * x1) + (b2 * x2))
bstart <- list(b0 = 1, b1 = 1, b2 = 1)

ml.nls <- nls(formula = ffl, start = bstart, data = siml)
mp.nls <- nls(formula = ffp, start = bstart, data = simp)


# ----------------------------------- #
# Evaluate models
# ----------------------------------- #

screenreg(l = list(ml.glm, ml.nls, mp.glm, mp.nls),
          custom.model.names = rep(c("GLM", "NLS"),2),
          custom.header      = list("Logit" = 1:2, "Probit" = 3:4),
          custom.coef.map    = list("(Intercept)" = "Int",
                                    "b0" = "Int",
                                    "x1" = "x1",
                                    "b1" = "x1",
                                    "x2" = "x2",
                                    "b2" = "x2"))

"The previous code serves as a good proof of concept that nls can be used to
 estimate binary outcome models. Now, how to incorporate space?"

rm(siml,simp, ml.glm, ml.nls, mp.glm, mp.nls, bstart, ffl, ffp)

#-----------------------------------------------------------------------------#
# SPATIAL: PROBIT -------------------------------------------------------------
simp = sp_sim(probit   = TRUE,
              b_true   = c(-1,2.3),
              rho_true = 0.5,
              k        = 1)
d = simp$data
w = as(simp$W_matrix, "CsparseMatrix")
table(d$y)


ml.glm <- glm(y ~ x1, data = d, family = binomial(link = "probit"))
summary(ml.glm)

ml.spr <- SpatialProbitFit(y ~ x1, data = d, W = w, DGP = "SAR")
summary(ml.spr)

#-----------------------------------------------------------------------------#
# SPATIAL: PROBIT VIA NLS -----------------------------------------------------
spc <- paste(sprintf("rho^%s * SpLag%s", 1:6, 1:6), collapse = " + ")
ffp <- as.formula(sprintf("y ~ pnorm(%s + b0 + (b1 * x1) )", spc))
# ffp <- as.formula(sprintf("y ~ ((%s) * pnorm(b0 + (b1 * x1) ))", spc))
# ffp <- as.formula(sprintf("y ~ (b0 + (b1 * x1)) * %s ", spc))

d2 <- sp_lag(lags = 6,
            W    = w,
            y    = d$y,
            X    = cbind(1, d$x1))
d2 <- d2[,2:ncol(d2)]
colnames(d2)[1] = "x1"
d2 <- cbind(d2, "y" = d$y)
head(d2)

bstart = list(rho = 0.3, b0 = 0, b1 = 0)

ml.nls <- nls(formula = ffp,
              start   = bstart,
              data    = d2)
summary(ml.nls)

rm(list=setdiff(ls(),"sp_sim"))


#-----------------------------------------------------------------------------#








#-----------------------------------------------------------------------------#
# SAVE ------------------------------------------------------------------------
# save.image()
# rm(list = ls())
