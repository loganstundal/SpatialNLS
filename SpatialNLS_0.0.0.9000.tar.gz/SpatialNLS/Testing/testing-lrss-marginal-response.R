#-----------------------------------------------------------------------------#
#
# Author:        Logan Stundal
# Date:          February 22, 2021
# Purpose:       Initial testing for spatio-temporal multipliers
#
#
# Copyright (c): Logan Stundal, 2021
# Email:         stund005@umn.edu
#
#-----------------------------------------------------------------------------#
#
# Notes:
#
#
#-----------------------------------------------------------------------------#



#-----------------------------------------------------------------------------#
# ADMINISTRATIVE                                                          ----
#-----------------------------------------------------------------------------#

#---------------------------#
# Clear working environment
#---------------------------#
rm(list = ls())

#---------------------------#
# Load required packages
#---------------------------#
# library(spatialreg)
library(SpatialNLS)
library(foreign)
library(tidyverse)

#---------------------------#
# Set working directory
#---------------------------#
# setwd()

#---------------------------#
# Load data
#---------------------------#



#-----------------------------------------------------------------------------#
# FUNCTION TESTING SPACE                                                  ----
#-----------------------------------------------------------------------------#






#-----------------------------------------------------------------------------#
# TESTING FUNCTIONS WRITTEN ABOVE                                         ----
#-----------------------------------------------------------------------------#





library(SpatialNLS)

x <- spacetime_sim2()

m <- lagsarnls(y ~ ylag + x1 + x2,
               data = x$data,
               W    = x$W_matrix)


n  <- length(unique(x$data$Group))
W2 <- x$W_matrix[1:n,1:n]


x1 <- impacts_ci(model = m,
                 W     = W2,
                 beta  = "x1",
                 phi   = "ylag",
                 unit_ids = x$data$Group,
                 time_ids = x$data$Time,
                 seed     = 123)

x2 <- impacts_ci(model = m,
                 W     = W2,
                 beta  = "x2",
                 phi   = "ylag",
                 unit_ids = x$data$Group,
                 time_ids = x$data$Time,
                 seed     = 123)


parameters::model_parameters(m)

x1
x2





#-----------------------------------------------------------------------------#
# WORKING SPACE BELOW                                                     ----
#-----------------------------------------------------------------------------#
dat <- read.dta("http://www-personal.umich.edu/~franzese/oxford_panel_data.dta")
Wp  <- as.matrix(read.dta("http://www-personal.umich.edu/~franzese/oxford_panel_w.dta"))
np  <- nrow(dat)

# Convert spatial weights matrix to a neighbor list object to use in models
neighbor_list_ts <- spdep::mat2listw(Wp,style="W")
Wp               <- spdep::listw2mat(neighbor_list_ts) # Row-standardizing "Wp"

# form = ben95 ~ ben95t1 + rskpovpc + wage95 + instcoad + ipcfold + teitrend + match + statenm
form = ben95 ~ ben95t1 + rskpovpc + wage95 + instcoad + ipcfold + teitrend + match

ben95.lagsartslm <- lagsarlm(formula = form,
                             data    = dat,
                             listw   = neighbor_list_ts)
summary(ben95.lagsartslm)


m.nls = lagsarnls(formula = form,
                  data    = dat,
                  W       = Wp)

n = length(unique(dat$statenm))
W = Wp[1:n,1:n]

impacts_ci(model = m.nls,
           W     = W,
           beta  = "wage95",
           phi   = "ben95t1",
           unit_ids = dat$statenm,
           time_ids = dat$year,
           seed     = 123)

# Does NOT account for temporal dynamics.
spatialreg::impacts(ben95.lagsartslm, listw = neighbor_list_ts)



#-----------------------------------------------------------------------------#
# Estimate LRSS
#-----------------------------------------------------------------------------#

dat  <- dat
t    <- length(unique(dat$year))
n    <- length(unique(dat$statenm))
nobs <- n * t

Id   <- diag(1, nobs, nobs)

rho  <- coef(ben95.lagsartslm)['rho']      # Extract spatial lag parameter from model
phi  <- coef(ben95.lagsartslm)['ben95t1']  # Extract temporal lag parameter from model
beta <- coef(ben95.lagsartslm)['wage95']   # Variable of interest - here we will look at wages

if(nobs != nrow(dat)){
  stop("da fuq you doin?")
}

# Generate L - lot's of inefficiencies here per rob (I need to refresh)
L <- diag(nobs-n)                 # 432x432 matrix with diagonal = 1, 0 elsewhere
L <- rbind(matrix(0,n,nobs-n),L)  # Add 48 rows to top of 0s to this [first year lag]
L <- cbind(L,matrix(0,nobs,n))    # Add 48 columns to right of 0s.


# ----------------------------------- #

# Estimate spatiotemporal multiplier
# M  <- solve(Id - rho*Wp - phi*L)

W2 <- W[1:n,1:n]
Wm <- do.call(magic::adiag, replicate(t, W2, simplify = FALSE))
M  <- solve(Id - rho*Wm - phi*L)


# Efficiency searching
  # M[1:5,1]
  #
  # Wm[1:5,1]
  # L[1:5,1]
  # Wm[1,1:5]
  # L[1,1:5]
  #
  # tst = (c(1, rep(0,239)) - rho * Wm[,1] - phi * L[,1])
  # length(tst)
  #
  # tst = diag(tst, 240,240)
  # tst = solve(tst)
  # tst[1:5,1]

# ----------------------------------- #



# Estimate marginal responses
bM <- beta * M

min_t = min(dat$year)
max_t = min_t + t

row_col_names <- paste(dat$statenm, rep(min_t:(max_t-1), each = n))
colnames(bM)  <- rownames(bM) <- row_col_names

bM[1:4, 1:4]
bM[476:480, 476:480]


# Examine response path of a shock in Minnesota : 1 in Minnesota; 2 in Wisconsin, 3 in California
# Shocks manifest in columns [I THINK?...]

range(dat$year)

mn <- bM[,"MN 81"]

mn2 <- as.data.frame(mn) %>%
  tibble::rownames_to_column(var = "StateYear") %>%
  mutate(State = unlist(purrr::map(strsplit(StateYear, " "),1)),
         Year  = unlist(purrr::map(strsplit(StateYear, " "),2))) %>%
  filter(State %in% c("MN","WI","CA")) %>%
  mutate(Year = as.numeric(Year)) %>%
  as_tibble()

# View(mn2)

mn3 <- mn2 %>%
  select(-StateYear) %>%
  pivot_wider(.,
              names_from = c(State),
              values_from = mn)


ggplot(data = mn2, aes(x = Year)) +
  geom_line(aes(y = mn, color = State)) +
  theme_minimal() +
  scale_x_continuous(breaks = seq(min_t,max_t,5),
                     labels = as.character(seq(min_t,max_t,5)))




# Cumulative response:
mn4 <- mn2 %>%
  group_by(State) %>%
  mutate(cumul_eff = cumsum(mn)) %>%
  ungroup()


ggplot(data = mn4, aes(x = Year)) +
  geom_line(aes(y = cumul_eff, color = State)) +
  theme_minimal() +
  scale_x_continuous(breaks = seq(min_t,max_t,5),
                     labels = as.character(seq(min_t,max_t,5)))

mn4 %>%
  group_by(State) %>%
  summarize(Max = max(cumul_eff))

impacts(model = m.nls,
        lag_dv = "ben95t1",
        W      = W,
        variable = "wage95",
        groups = dat$state)


# ----------------------------------- #

t    <- 10                # Number of time units
nobs <- n*t               # Now the number of observation is N x T, not N
Id   <- diag(1,nobs,nobs)

# Create the Time-Lag Generating Matrix, "L" with dimension (480 * 480):
# The first 48 rows of L are 0s.
# The last 48 cols of L are 0s.
# (480-48) * (480-48) diagonal submatrix in the lower left corner
L <- diag(nobs-n)                 # 432x432 matrix with diagonal = 1, 0 elsewhere
L <- rbind(matrix(0,n,nobs-n),L)  # Add 48 rows to top of 0s to this [first year lag]
L <- cbind(L,matrix(0,nobs,n))    # Add 48 columns to right of 0s.


# Estimate LRSS for Spatio-Temporal Data: -- NOTICE: "L" rather than "Id"
M  <- solve(Id - rho*Wp - phi*L)

# Estimate response (marginal responses)
bM <- beta * M

# Now our marginal responses are an NT*NT matrix (480x480), we can
# adjust the column and row names to make it more understandable:

row_col_names <- paste(dat$statenm, dat$year)
# Combine each unique state name which is the state abbreviation and year.
# We will use this to label our matrices to make it easier to work with them.

colnames(bM) = rownames(bM) = row_col_names

# Now inspect top-left and bottom-right corner of response matrix:
bM[1:4, 1:4]
bM[476:480, 476:480]


# 7.5 Marginal Response Uncertainty via Parametric Simulation -----------------
sims  <- 200                  # Number of simulations to run

# For lab - lowered sims from 1000 to 200 here for lab. This takes time.
# On your own time, however, 1000 would be a more appropriate number of
# simulations to run.

sim.effs <- array(data     = 0,
                  dim      = c(nobs,nobs,sims),
                  dimnames = list(row_col_names,
                                  row_col_names))

for(i in 1:sims){
  if(i %in% seq(100, sims, by = 100)){
    print(sprintf('Working on iteration: %s', i))
  }

  draws <- mvrnorm(n         = 1,
                   mu        = c(rho, phi, beta),
                   Sigma     = VCVM)

  sim.rho  = draws['rho']
  sim.beta = draws['wage95']
  sim.phi  = draws['ben95t1']

  sim.m  = solve(Id - sim.rho * Wp - sim.phi * L)
  sim.bm = sim.beta * sim.m

  rownames(sim.bm) = colnames(sim.bm) =  row_col_names

  sim.effs[,,i] = sim.bm
}
# Clean-up, remove unecessary objects left-over from simulation
rm(draws, sim.rho, sim.beta, sim.m, sim.bm)

# EVALUATE SIMULATION RESULTS
# NOTE - sim.effs: each ROW represents the simulated counterfactual effect in
#        that state-yr of a unit increase in "wage95" in the COLUMN state-yr

# Unit change of "wage95" in Alabama on Florida
median(sim.effs['FL 81','AL 81',])
hist(sim.effs['FL 81','AL 81',])
quantile(sim.effs['FL 81','AL 81',], probs = c(0.025, 0.975))




















