

# build package
build(
  path      = proj_path(),
  vignettes = FALSE
)
