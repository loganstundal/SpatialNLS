#-----------------------------------------------------------------------------#
#
# Author:        Logan Stundal
# Date:          February 02, 2021
# Purpose:       Note
#
#
# Copyright (c): Logan Stundal, 2021
# Email:         stund005@umn.edu
#
#-----------------------------------------------------------------------------#
#
# Notes:
#       Evaluate performance of NLS under variety of use cases.
#
#-----------------------------------------------------------------------------#


# Motivation:

"Increased complexity isn't always better - why NLS offers advantages for spatial methods progress:

Political scientists increasingly engage with spaital data in our analysis of political phenomena.
This is a great indication of the progress in the discipline - as political scientists gain access to
more accurate, highly precise measures of political variables that include indicators on spatial
information we are able to make new inroads into understanding problems that were once out of reach. This
progress brings with it advances in our theorization. Rather than simply treating space as a nuisance we now
work much more to incorporate it directly into our theoretical models. These more sophisticated theories have
generated intense methodoloigcal research on ways to incorporate the theoretically implied dynamics of space
into our statistical models which seek to measure processes. However, this development of sophisticated modeling
techniques along with the aforementioned expansion of spatial data access has given rise to a new
problem - computation. These new models of space present extensive computational challenges. Often the technical
difficulties of estimation serve as a new impediment to theoretical progress. Solutions typically seek
to address the computational challenges of space through complexity - that is, the proposed solutions typically
are more advanced statistical methods. For example INLA or Singranelli and XYZ on their probit estimator [See also
Stundal 2020 et al for more on this.]. While these state-of-the-art developments in the domain of spatial modeling
offer exciting new avenues for future research they also present an impediment for future theoretical progress
in our discipline as they exclude large swathes of researchers who lack the technical expertise to engage with
and successfully deploy these models. Worse, finding that existing methods provide no feasible solutions to a
technical estimation problem, some researchers may turn to these more sophisticated techniques without a full
appreciation of the particular featuers of the models required for successful theory testing. In order to
address this problem in this paper I instead offer an alternative solution for applied researchers seeking to
model the spatial dynamics of their newly acquired large-n spatially explitic datasets: Spatial Lag and Spatial
Error regression estimated via non-linear least squares. In contrast to more complex tecniques such as Bayesian
models estimated via MCMC or INLA, or optimization routines that struggle to successfully converge when
contfonted with complicated liklihoods inherent to dynamic spatial processes, nonlinear least squares (NLS)
offers a number of attractive features including familiariaty for many researchers already trained in
ordinary least squares and speed - NLS can provide estimates for complex spatial models in a fraction of the
time of comparable models estimated via maximum likelihood or Bayesian techniques. In the remainder of this paper
I will introduce the NLS Spatial Lag and Spatial Error model as well as explain the purpose and areas for
research applications. Following this I will discuss the preformance of these NLS models compared to a number
of more complex competitors. Finally, I will review a new software package available now in R, Python, and
Stata for researchers to use in their applied spatial studies. Following this presentation of the automated
commands from the software, the paper explores extensions of the sptial lag model germane to the study of
poltiical process that incorporate dynamics implied by our theories more directly into our statistical models."

"Could also offer a heteroskedasticity fix. Spatial models have heteroskedasticity but it is NEVER EVER addressed."

#-----------------------------------------------------------------------------#
# ADMINISTRATIVE --------------------------------------------------------------

#---------------------------#
# Clear working environment
#---------------------------#
rm(list = ls())

#---------------------------#
# Load required packages
#---------------------------#
library(tidyverse)
library(spatialreg)
library(microbenchmark)
library(texreg)

#---------------------------#
# Set working directory
#---------------------------#
# setwd()

#---------------------------#
# Load data
#---------------------------#
source("lagsarnls.R")



#-----------------------------------------------------------------------------#
# SPDEP SAMPLE DATA -----------------------------------------------------------

# ----------------------------------- #
# Import data and relevant spatial weights
# ----------------------------------- #
data(oldcol, package="spdep")
listw <- spdep::nb2listw(COL.nb, style="W")
W <- as(listw, "CsparseMatrix")


# ----------------------------------- #
# Evaluate Models - Accuracy
# ----------------------------------- #
# Model formula
ff <- CRIME ~ INC + HOVAL + INC * HOVAL

# Estimate models
mspr <- lagsarlm( formula = ff, data = COL.OLD, listw=listw, quiet=T)
mnls <- lagsarnls(formula = ff, data = COL.OLD, W = W)

# Compare estimates:
screenreg(l = list(mspr, mnls),
          custom.coef.map = list("(Intercept)" = "Intercept",
                                 "INC:HOVAL"   = "INC_HOVAL",
                                 "b_Intercept" = "Intercept",
                                 "b_INC"       = "INC",
                                 "INC"         = "INC",
                                 "b_INC_HOVAL" = "INC_HOVAL",
                                 "rho"         = "rho"),
          custom.model.names = c("SpatialReg","NLS"))



#-----------------------------------------------------------------------------#
# SIMULATED DATA - One condition set ------------------------------------------

# 20210202 -- MESSY EXPERIMENTING CODE FOLLOWS IN THIS CHUNK

# ----------------------------------- #
# Simulate data - note, "sp_sim" from my lagsarnls script
# ----------------------------------- #
ff   <- y ~ x1

b_true = c(1,2)
rho_true = 0.7
sim <- sp_sim(n          = 200,
              k          = length(b_true)-1,
              b_true     = b_true,
              rho_true   = rho_true,
              prob_connect = 0.7,
              e_sd         = 0.2)

d     <- sim$data
listw <- sim$W_list
W     <- sim$W_matrix

sim$sim_params$nbr_connections_sim

# ----------------------------------- #
# Test models on simulated data
# ----------------------------------- #

# spdep::moran.mc(d$y, listw = listw, nsim = 200)
# spdep::moran.plot(d$y, listw = listw)

# Estimate models
m0   <- lm(ff, d)
mspr <- lagsarlm( formula = ff, data = d, listw=listw, quiet=T)
mnls1 <- lagsarnls(formula = ff, data = d, W = W, lags = 6)
mnls2 <- lagsarnls(formula = ff, data = d, W = W, lags = 6, rho_bounds = c(-0.95, 0.95))

# Compare estimates:
screenreg(l = list(m0, mspr, mnls1,mnls2),
          custom.coef.map = list("(Intercept)" = "Intercept",
                                 "b_Intercept" = "Intercept",
                                 "b_x1"        = "x1",
                                 "b_x2"        = "x2",
                                 "x1"          = "x1",
                                 "x2"          = "x2",
                                 "rho"         = "rho"),
          custom.model.names = c("OLS","SpatialReg","NLS - Unbound","NLS - Bound"))

spdep::lm.LMtests(m0, listw = listw, test = 'all')



# NOTE - because nls() is generic, confint(mnls1) works! This also works on the
#        spatialreg lagsarlm() output: confint(mspr)

# This could be useful to evaluate precision in addition to accuracy in the sim.

# FUTURE NOTES:
"interested in where the 'detection zone' is for these models, that is what is their power
 to detect spatial dependence? as rho nears 0 (~rho < 0.35) or if the sample size is small
 (~ n < 100) it appears that BOTH models struggle. but I need to verify this systematically."


#-----------------------------------------------------------------------------#



# Leveraging Idris and Zorn's 2013 Polmeth poster I've looked at so often over the years

# This will work fine in the simulation, but here makes less sense
# percent_absolute_bias <- function(b, b_true, n_sim){
#   return((sum(b - b_true) / sum(b)) * 100 )
# }

# Percentage difference should be = ((model - observed)/observed) *100

# percent_absolute_bias(b = coef(m0), b_true = b_true, n_sim = n_sim)


# ----------------------------------- #
# Single model percent bias calculations!
# ----------------------------------- #
pbias = data.frame("OLS"        = c("rho" = NA,((coef(m0) - b_true) / b_true) * 100),
                   "SpatialReg" = ((coef(mspr) - c(rho_true,b_true)) / c(rho_true, b_true)) * 100,
                   "My_NLS"     = ((coef(mnls1)[c(4,1:3)] - c(rho_true,b_true)) / c(rho_true, b_true)) * 100)

# ((coef(mnls2)[c(4,1:3)] - c(rho_true,b_true)) / c(rho_true, b_true)) * 100

round(pbias,2)


#-----------------------------------------------------------------------------#
# FULL SIMULATION -------------------------------------------------------------


# ----------------------------------- #
# Simulation parameters
# ----------------------------------- #

"What do I want to capture in these simulations?

1. PAB in [Beta] and [Rho] across a range of :
    - sample sizes
    - W connections (maybe)
    - e (white noise) standard deviation, or heteroskedasticity

2. Choose 2 of the above 3 for xy heat maps

3. Present these xy heat maps for [SP  |  NLS] MODELS @ 3-sample sizes (So, 2*6 = 6 plots)

"

nsims       = 10 # (1000 + better in full)
# sample_size = c(50, 100, 400, 800) # W increases exponentially with n
sample_size = c(20, 40, 100, 200)
rho_vals    = seq(0.20, 0.8,.20)
b_true      = c(1, 2)

ff   <- y ~ x1

res_ols = data.frame()
res_spr = data.frame()
res_nls = data.frame()

# res_sim = list()       # Save simulation data and parameters here.

for(n in sample_size){
  for(r in rho_vals){
    for(i in 1:nsims){
      # Magic happens here.

      # ----------------------------------- #
      # Simulate data for iteration i
      # ----------------------------------- #
      sim_id = sprintf("n_%s_Rho_%s_%s", n,r,i)

      cat("\14");print(sprintf("Working on sample size: %s, rho value: %s | Iteration %s of %s",n, r, i, nsims))

      sim = sp_sim(sample_size  = n,
                   k            = length(b_true)-1,
                   b_true       = b_true,
                   rho_true     = r,
                   prob_connect = 0.7,
                   e_sd         = 0.2)

      d     = sim$data
      listw = sim$W_list
      W     = sim$W_matrix

      # Save simulation data for iteration i
      # For now disabled - saving data without W would be pointless, but all
      # the Ws will take up a ton of space...
      # res_sim[[sprintf("sim_%s",i)]] = sim[c("sim_params","data")]
      # ----------------------------------- #


      # ----------------------------------- #
      # Test models on simulated data - FUTURE NOTE (COULD SAVE AND STORE EST TIMES FROM HERE)
      # ----------------------------------- #
      olsm = lm(       formula = ff, data = d)
      sprm = lagsarlm( formula = ff, data = d, listw=listw, quiet=T)
      nlsm = lagsarnls(formula = ff, data = d, W = W, lags = 6)
      # nls2 <- lagsarnls(formula = ff, data = d, W = W,
      #                   lags = 6, rho_bounds = c(-0.95, 0.95))
      # ----------------------------------- #


      # ----------------------------------- #
      # Extract model coefficients and save to DFs
      # ----------------------------------- #
      # Extract coefficients
      olsm = olsm %>% coef
      sprm = sprm %>% coef
      nlsm = nlsm %>% coef

      # Safe to DFs
      res_ols = bind_rows(res_ols, c("b0"  = as.numeric(olsm["(Intercept)"]),
                                     "b1"  = as.numeric(olsm["x1"]),
                                     "rho" = NA,
                                     "Sample_Size" = n,
                                     "RhoTrue"     = r))

      res_spr = bind_rows(res_spr, c("b0"  = as.numeric(sprm["(Intercept)"]),
                                     "b1"  = as.numeric(sprm["x1"]),
                                     "rho" = as.numeric(sprm["rho"]),
                                     "Sample_Size" = n,
                                    "RhoTrue"     = r))

      res_nls = bind_rows(res_nls, c("b0"  = as.numeric(nlsm["b_Intercept"]),
                                     "b1"  = as.numeric(nlsm["b_x1"]),
                                     "rho" = as.numeric(nlsm["rho"]),
                                     "Sample_Size" = n,
                                     "RhoTrue"     = r))
      # ----------------------------------- #


      # ----------------------------------- #
      # Iteration clean-up
      # ----------------------------------- #
      rm(sim_id, sim, d, listw, W,
         olsm, sprm, nlsm)
      # ----------------------------------- #
    }
  }
}

# ----------------------------------- #
# Post-simulation clean-up
# ----------------------------------- #
rm(n, r, i)
# ----------------------------------- #


# Percentage difference should be = ((model - observed)/observed) *100
# pbias <- function(x,y){return(((x - y) / y) * 100)}   # Either direction
pbias <- function(x,y){return((abs(x - y) / y) * 100)}   # Absolute bias

# ----------------------------------- #
# Tidy Simulation dataframes
# ----------------------------------- #
res_ols2 <- res_ols %>%
  mutate(bias_b0  = pbias(b0,  b_true[1]),
         bias_b1  = pbias(b1,  b_true[2]),
         bias_rho = pbias(rho, RhoTrue)) %>%
  group_by(Sample_Size, RhoTrue) %>%
  summarize(across(starts_with("b"), .fns = mean)) %>%
  ungroup() %>%
  mutate(Sample_Size = as_factor(Sample_Size),
         RhoTrue     = as_factor(RhoTrue))

summary(res_ols2[,c("b0","b1","bias_b0","bias_b1")])


res_spr2 <- res_spr %>%
  mutate(bias_b0  = pbias(b0,  b_true[1]),
         bias_b1  = pbias(b1,  b_true[2]),
         bias_rho = pbias(rho, RhoTrue)) %>%
  group_by(Sample_Size, RhoTrue) %>%
  summarize(across(c(starts_with("b"),rho), .fns = mean)) %>%
  ungroup() %>%
  mutate(Sample_Size = as_factor(Sample_Size),
         RhoTrue     = as_factor(RhoTrue))

summary(res_spr2[,c("b0","b1","bias_b0","bias_b1","rho", "bias_rho")])

res_nls2 <- res_nls %>%
  mutate(bias_b0  = pbias(b0,  b_true[1]),
         bias_b1  = pbias(b1,  b_true[2]),
         bias_rho = pbias(rho, RhoTrue)) %>%
  group_by(Sample_Size, RhoTrue) %>%
  summarize(across(c(starts_with("b"),rho), .fns = mean)) %>%
  ungroup() %>%
  mutate(Sample_Size = as_factor(Sample_Size),
         RhoTrue     = as_factor(RhoTrue))

summary(res_nls2[,c("b0","b1","bias_b0","bias_b1","rho", "bias_rho")])



"NOTE !!!! These biases massively UNDERSTATE the full bias of the estimates
            because they do NOT incorporate the dyanmics into the error estimate."




#-----------------------------------------------------------------------------#
# SAVE SIMULATION RESULTS






#-----------------------------------------------------------------------------#
# PLOTS - Simulation Results --------------------------------------------------


# https://www.r-graph-gallery.com/79-levelplot-with-ggplot2.html

# OLS
ols_b0 <- ggplot(data = res_ols2, aes(x = Sample_Size, y = RhoTrue, fill = bias_b0)) +
  geom_tile() +
  scale_fill_distiller("% Abs. Bias",
                       palette = "Spectral",
                       limits  = c(0,720),
                       labels  = scales::label_percent(scale = 1)) +
  labs(title = "OLS, beta 0",
       y     = "Rho",
       x     = "Sample Size")

ols_b1 <- ggplot(data = res_ols2, aes(x = Sample_Size, y = RhoTrue, fill = bias_b1)) +
  geom_tile() +
  scale_fill_distiller("% Abs. Bias",
                       palette = "Spectral",
                       limits  = c(0,3),
                       labels  = scales::label_percent(scale = 1)) +
  labs(title = "OLS, beta 1",
       y     = "Rho",
       x     = "Sample Size")

# Spatial Regression - spatialreg
spr_b0 <- ggplot(data = res_spr2, aes(x = Sample_Size, y = RhoTrue, fill = bias_b0)) +
  geom_tile() +
  scale_fill_distiller("% Abs. Bias",
                       palette = "Spectral",
                       limits  = c(0,720),
                       labels  = scales::label_percent(scale = 1)) +
  labs(title = "Spatial Regression (spatialreg), beta 0",
       y     = "Rho",
       x     = "Sample Size")

spr_b1 <- ggplot(data = res_spr2, aes(x = Sample_Size, y = RhoTrue, fill = bias_b1)) +
  geom_tile() +
  scale_fill_distiller("% Abs. Bias",
                       palette = "Spectral",
                       limits  = c(0,3),
                       labels  = scales::label_percent(scale = 1)) +
  labs(title = "Spatial Regression (spatialreg), beta 1",
       y     = "Rho",
       x     = "Sample Size")

spr_rh <- ggplot(data = res_spr2, aes(x = Sample_Size, y = RhoTrue, fill = bias_rho)) +
  geom_tile() +
  scale_fill_distiller("% Abs. Bias",
                       palette = "Spectral",
                       limits  = c(0,80),
                       labels  = scales::label_percent(scale = 1)) +
  labs(title = "Spatial Regression (spatialreg), rho",
       y     = "Rho",
       x     = "Sample Size")

# Spatial Regression - NLS
nls_b0 <- ggplot(data = res_nls2, aes(x = Sample_Size, y = RhoTrue, fill = bias_b0)) +
  geom_tile() +
  scale_fill_distiller("% Abs. Bias",
                       palette = "Spectral",
                       limits  = c(0,720),
                       labels  = scales::label_percent(scale = 1)) +
  labs(title = "Spatial Regression (nls), beta 0",
       y     = "Rho",
       x     = "Sample Size")

nls_b1 <- ggplot(data = res_nls2, aes(x = Sample_Size, y = RhoTrue, fill = bias_b1)) +
  geom_tile() +
  scale_fill_distiller("% Abs. Bias",
                       palette = "Spectral",
                       limits  = c(0,3),
                       labels  = scales::label_percent(scale = 1)) +
  labs(title = "Spatial Regression (nls), beta 1",
       y     = "Rho",
       x     = "Sample Size")

nls_rh <- ggplot(data = res_nls2, aes(x = Sample_Size, y = RhoTrue, fill = bias_rho)) +
  geom_tile() +
  scale_fill_distiller("% Abs. Bias",
                       palette = "Spectral",
                       limits  = c(0,80),
                       labels  = scales::label_percent(scale = 1)) +
  labs(title = "Spatial Regression (nls), rho",
       y     = "Rho",
       x     = "Sample Size")



# Arrange plots
library(cowplot)
# https://wilkelab.org/cowplot/articles/plot_grid.html

plot_grid(
  ols_b0, ols_b1, NULL,
  spr_b0, spr_b1, spr_rh,
  nls_b0, nls_b1, nls_rh,
  # ols_b1, NULL,
  # spr_b1, nls_b1,
  # spr_rh, nls_rh,
  labels = "AUTO",
  ncol   = 3
)



#-----------------------------------------------------------------------------#
# TIMING DATA -----------------------------------------------------------------
library(microbenchmark)

# Ideally 2000+ but want this code to actually run for testing purposes
data_big <- sp_sim(sample_size  = 400,
                   k            = length(b_true)-1,
                   b_true       = b_true,
                   rho_true     = 0.5,
                   prob_connect = 0.7,
                   e_sd         = 0.2)

data_sml <- sp_sim(sample_size  = 100,
                   k            = length(b_true)-1,
                   b_true       = b_true,
                   rho_true     = 0.5,
                   prob_connect = 0.7,
                   e_sd         = 0.2)


mbm_sml <- microbenchmark("SpatialReg" = {lagsarlm( formula = ff, data = data_sml$data, listw=data_sml$W_list, quiet=T)},
                          "SpatialNLS" = {lagsarnls(formula = ff, data = data_sml$data, W = data_sml$W_matrix)})

mbm_big <- microbenchmark("SpatialReg" = {lagsarlm( formula = ff, data = data_big$data, listw=data_big$W_list, quiet=T)},
                          "SpatialNLS" = {lagsarnls(formula = ff, data = data_big$data, W = data_big$W_matrix)})


# ----------------------------------- #
# Plot timing data
# ----------------------------------- #

plt_sml <- autoplot(mbm_sml) + theme_minimal()
plt_big <- autoplot(mbm_big) + theme_minimal()

# plot_grid(plt_sml, plt_big, nrow = 2)

plt_dat <- bind_rows(as.data.frame(plt_sml$data) %>% mutate(Group = "Small-n = 100"),
                     as.data.frame(plt_big$data) %>% mutate(Group = "Large-n = 800")) %>%
  mutate(time = time / 1e6) # Convert nanoseconds (?) to milliseconds [latter validated with plots]


ggplot(data = plt_dat, aes(x = time, y = expr)) +
  geom_violin(aes(fill = expr)) +
  facet_wrap(vars(Group), nrow = 2) +
  scale_fill_discrete("Function") +
  theme_minimal() +
  theme(panel.grid.major.y = element_blank())


"This performance plot is a pretty important observation here - these models offer a
 tractable solution to estimating complex dynanmic spatial models. This solution also
 scales well as the data grow. "

# ----------------------------------- #
# Performance measure quantified
# ----------------------------------- #
mbm_sml <- as.data.frame(summary(mbm_sml))[,c("min","mean","max")]
mbm_big <- as.data.frame(summary(mbm_big))[,c("min","mean","max")]

mbm_sml[1, ] / mbm_sml[2,]
mbm_big[1, ] / mbm_big[2,]

"On average, my Spatial-NLS function is between 30 to 70 times faster than
 lagsarlm when estimating these on the small data and 12 to 16 times faster
 on a large-n dataset."



#-----------------------------------------------------------------------------#







