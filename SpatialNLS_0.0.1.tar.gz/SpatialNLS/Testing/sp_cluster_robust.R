

# taken from icpsr 2020 lab3.r

# ----------------------------------- #
# Estimate clusters HC standard errors "by hand"
# Knowing how to do this manually can be useful if there is a model you've estimated
# but which is not supported by these existing commands

## what's actually going on inside the package: robust clustered standard errors "by hand"
X <- model.matrix(ols.fit)
k <- ncol(X)

## new dataset only with covariates in the model
my.data = my.data[,c("country","year","enep1",colnames(X)[-1])]
my.data = na.omit(my.data)

G <- length(unique(my.data$country))
N <- nrow(X)
Omega <- matrix(0,N,N)

err     <- as.matrix(ols.fit$residuals)
err.mat <- err %*% t(err)

## allow within-group standard errors to be correlated, between-group standard errors are still assumed to be 0.
countryID <- unique(my.data$country)
for(i in 1:G){
  id = which(my.data$country == countryID[i])
  Omega[id,id] = err.mat[id,id]
}

Vhc = solve(t(X) %*% X) %*% t(X) %*% Omega %*% X %*% solve(t(X) %*% X)
cluster.vcv.hand = ((N-1)/(N-k))*Vhc ## DoF adjustment, produces a robust clustered vcov matrix

# compare
cbind('Sandwich Pkg' = sqrt(diag(cluster.vcv.sandwich)),
      'By hand'      = sqrt(diag(cluster.vcv.hand)))
# ----------------------------------- #

# USING SPATIAL RES FROM 2.0-MODELS-SPATIAL-FIT.R dissertation script.


d <- sp_lri$data
ws <- sp_lri$w_sub



dd <- model.frame(ns_lri$model)
X <- model.matrix(formula(ns_lri$model), dd) 
k <- ncol(X)

my.data <- as.data.frame(X)

G <- length(unique(dd$cname))
N <- nrow(X)
Omega <- matrix(0,N,N)

err     <- as.matrix(resid(sp_lri$model))
err.mat <- err %*% t(err)

## allow within-group standard errors to be correlated, between-group standard errors are still assumed to be 0.
countryID <- unique(dd$cname)
for(i in 1:G){
  id = which(dd$cname == countryID[i])
  Omega[id,id] = err.mat[id,id]
}
Vhc = solve(t(X) %*% X) %*% t(X) %*% Omega %*% X %*% solve(t(X) %*% X)
cluster.vcv.hand = ((N-1)/(N-k))*Vhc ## DoF adjustment, produces a robust clustered vcov matrix

cbind(
ses.orig <- sp_lri$ses[74:77],
ses.cl   <- sqrt(diag(cluster.vcv.hand))[74:77]
)
