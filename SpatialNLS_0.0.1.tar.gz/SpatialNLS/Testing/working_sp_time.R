

# 2021 02 23 -- CAN PROBABLY DELETE THIS TESTING SCRIPT SOON.

#-----------------------------------------------------------------------------#
# Testing models
#-----------------------------------------------------------------------------#
rm(list=ls())

library(spatialreg)

set.seed(123)

# ?spacetime_sim2
x = spacetime_sim2()

d  = x$data
Wm = x$W_matrix
Wl = x$W_list

tv = x$params

rm(x)


# ----------------------------------- #
# look at trends in 4 of the units over time
# ----------------------------------- #
  # tst <- d %>%
  #   filter(Group %in% c("A", "B","C","D"))
  #
  # ggplot(data = tst, aes(x = as.numeric(Time), y = y)) +
  #   geom_line(aes(color = Group))
# ----------------------------------- #
#-----------------------------------------------------------------------------#


# Basic model, no space or time
m0 = lm(y ~ x1 + x2, data = d)
# get_params(m0, names(coef(m0)), tv)
ests = coef(m0)[c("(Intercept)","x1","x2")]
trus = tv$b_true
tibble::tibble("Vars" = c("(Intercept)","x1","x2"),
               "Estimates" = ests, "Truths" = trus)

# Include lag, no space
m1 = lm(y ~ ylag + x1 + x2, data = d)
# get_params(m1, names(coef(m1)), tv)
ests = coef(m1)[c("(Intercept)","x1","x2", "ylag")]
trus = c(tv$b_true, tv$phi_true)
tibble::tibble("Vars" = c("(Intercept)","x1","x2","ylag"),
               "Estimates" = ests, "Truths" = trus)


# My spacetime nls - include space and time
m2 = lagsarnls(formula = y ~ ylag + x1 + x2, data = d, W = Wm)
# get_params(m2, names(coef(m2)), tv)
ests = coef(m2)[c("b_Intercept","b_x1","b_x2", "b_ylag", "rho")]
trus = c(tv$b_true, tv$phi_true, tv$rho_true)
tibble::tibble("Vars" = c("(Intercept)","x1","x2","ylag", "rho"),
               "Estimates" = ests, "Truths" = trus)

# Spatialreg
m3 = lagsarlm(formula = y ~ ylag + x1 + x2, data = d, listw = Wl)
ests = coef(m3)[c("(Intercept)","x1","x2", "ylag", "rho")]
trus = c(tv$b_true, tv$phi_true, tv$rho_true)
tibble::tibble("Vars" = c("(Intercept)","x1","x2","ylag", "rho"),
               "Estimates" = ests, "Truths" = trus)

# ----------------------------------- #

# FEs
m4 = lm(y ~ x1 + x2 + Group + Time, data = d)
ests = coef(m4)[c("(Intercept)","x1","x2")]
trus = c(tv$b_true[1:(1+tv$k)])
tibble::tibble("Vars" = c("(Intercept)","x1","x2"),
               "Estimates" = ests, "Truths" = trus)

m5 = lm(y ~ ylag + x1 + x2 + Group + Time, data = d)
ests = coef(m5)[c("(Intercept)","x1","x2","ylag")]
trus = c(tv$b_true[1:(1+tv$k)], tv$phi_true)
tibble::tibble("Vars" = c("(Intercept)","x1","x2","ylag"),
               "Estimates" = ests, "Truths" = trus)


m6 = lagsarnls(y ~ ylag + x1 + x2 + Group + Time, data = d, W = Wm)
ests = coef(m6)[c("b_Intercept","b_x1","b_x2","b_ylag","rho")]
trus = c(tv$b_true[1:(1+tv$k)], tv$phi_true, tv$rho_true)
tibble::tibble("Vars" = c("(Intercept)","x1","x2","ylag", "rho"),
               "Estimates" = ests, "Truths" = trus)

m7 = lagsarlm(formula = y ~ ylag + x1 + x2 + Group + Time, data = d, listw = Wl)
ests = coef(m7)[c("(Intercept)","x1","x2", "ylag", "rho")]
trus = c(tv$b_true, tv$phi_true, tv$rho_true)
tibble::tibble("Vars" = c("(Intercept)","x1","x2","ylag", "rho"),
               "Estimates" = ests, "Truths" = trus)



#-----------------------------------------------------------------------------#



# Fuck this code
# require(stringr)
# get_params <- function(model, params, sim_vals){
#   ests = coef(model)[params]
#   names(ests) = str_replace(names(ests), "ylag", "phi")
#   names(ests) = str_replace_all(names(ests), "b_", "")
#   names(ests) = str_replace(names(ests), "rho",  "rho")
#
#   params = str_replace(params, "ylag", "phi_true")
#   params = str_replace(params, "rho",  "rho_true")
#
#
#
#   if(any(str_detect(params, "phi_true")) & any(str_detect(params, "rho_true"))){
#     trus = c(sim_vals$b_true, sim_vals$phi_true, sim_vals$rho_true)
#     params = c("(Intercept)",params[str_starts(params, "x")], "phi_true" , "rho_true")
#     ests = ests[c("(Intercept)", names(ests)[str_starts(names(ests), "x")], "phi", "rho")]
#   } else if(any(str_detect(params, "phi_true")) & !any(str_detect(params, "rho_true"))){
#     trus = c(sim_vals$b_true, sim_vals$phi_true)
#     params = c("(Intercept)",params[str_starts(params, "x")], "phi_true")
#     ests = ests[c("(Intercept)", names(ests)[str_starts(names(ests), "x")], "phi")]
#   } else if(!any(str_detect(params, "phi_true")) & any(str_detect(params, "rho_true"))){
#     trus = c(sim_vals$b_true, sim_vals$rho_true)
#     params = c("(Intercept)",params[str_starts(params, "x")], "rho_true")
#     ests = ests[c("(Intercept)", names(ests)[str_starts(names(ests), "x")], "rho")]
#   } else{
#     trus = sim_vals$b_true
#   }
#   m_name = deparse(substitute(model))
#   return(tibble::tibble("Param"      = params,
#                         "Estimates"  = ests,
#                         "TrueValues" = trus,
#                         "Model"      = m_name))
#   }










