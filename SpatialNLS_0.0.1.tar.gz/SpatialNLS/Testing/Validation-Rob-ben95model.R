
library(foreign)
# test my function call with robs data and code:
oxford_panel <- read.dta("http://www-personal.umich.edu/~franzese/oxford_panel_data.dta")
Wp           <- as.matrix(read.dta("http://www-personal.umich.edu/~franzese/oxford_panel_w.dta"))

# Convert spatial weights matrix to a neighbor list object to use in models
neighbor_list_ts <- mat2listw(Wp,style="W")
Wp               <- listw2mat(neighbor_list_ts) # Row-standardizing "Wp"

form = ben95 ~ ben95t1 + rskpovpc + wage95 + instcoad + ipcfold + teitrend + match + statenm

ben95.lagsartslm <- lagsarlm(formula = form,
                             data    = oxford_panel,
                             listw   = neighbor_list_ts)

ben95.nls <- lagsarnls(formula = form,
                       data    = oxford_panel,
                       W       = Wp)


# Panel Model comparison
library(texreg)
screenreg(l = list(ben95.lagsartslm, ben95.nls),
          custom.model.names = c('Spatial-Temporal Lag', "My NLS"),
          custom.coef.map    = list('(Intercept)' = 'Intercept',
                                    'rskpovpc'    = 'rskpovpc',
                                    'wage95'      = 'wage95',
                                    'instcoad'    = 'instcoad',
                                    'teitrend'    = 'teitrend',
                                    'match'       = 'match',
                                    'ben95t1'     = 'Temporal Lag (ben95t1)',

                                    'b_Intercept' = 'Intercept',
                                    'b_rskpovpc'    = 'rskpovpc',
                                    'b_wage95'      = 'wage95',
                                    'b_instcoad'    = 'instcoad',
                                    'b_teitrend'    = 'teitrend',
                                    'b_match'       = 'match',
                                    'b_ben95t1'     = 'Temporal Lag (ben95t1)',


                                    'rho'         = 'Spatial Lag (Rho)') )
summary(ben95.nls)



library(microbenchmark)


m <- microbenchmark(
  "lagsarlm" = {lagsarlm(formula = form,
                         data    = oxford_panel,
                         listw   = neighbor_list_ts)},
  "lagsarnls" = {lagsarnls(formula = form,
                           data    = oxford_panel,
                           W       = Wp)}
)

autoplot(m) + theme_minimal()


W2  = as(Wp, "sparseMatrix")
tst = lagsarnls(formula = form,
                data    = oxford_panel,
                W       = W2)

m <- microbenchmark(
  "W_matrix" = {lagsarnls(formula = form,
                           data    = oxford_panel,
                           W       = Wp)},

  "W_sparseM" = {lagsarnls(formula = form,
                           data    = oxford_panel,
                           W       = W2)}
)

autoplot(m) + theme_minimal()
