
rm(list=ls())


b0 = -2
b1 =  2
lambda = 0.6

n <- 250

x <- rnorm(n)

p <- 0.4

w <- rbinom(n^2, 1, p)
w <- matrix(w, nrow = n)
w[lower.tri(w)] = t(w)[lower.tri(w)]
diag(w) = 0
isSymmetric(w)


Id <- diag(1,n)

# ----------------------------------- #
# row standardize
# ws <- apply(w, 1, function(x){ x / sum(x)})

wsp <- spdep::mat2listw(w, style = "W")
# ----------------------------------- #


#white noise
e <- rnorm(n)
e <- as.vector(solve(Id - lambda * w) %*% e)

y <- b0 + b1 * x + e
d <- data.frame(y = y, x = x)

m <- lm(y ~ x, data = d)
summary(m)


library(spatialreg)

m2 <- errorsarlm(y ~ x, data = d, listw = wsp)
summary(m2)
