

"
Working on in this script:
Impacts for LRSS and simulated CIs using eigenvalues rather than W
works here. Still need to work on estimating the response path values
at each time-unit. Confused about what the results are showing in the
object below called tst.

Code is really messy.

Problem is likely that L-matrix produces the first-lag? Also, inefficient
in the 0s on the right to make the matrix symmetric may have to do with
inconsistencies in the mean of bM when compared to eigen method.
"


rm(list=ls())
library(dplyr)       # mutate relocate bind_rows
library(magrittr)    # `%>%`
library(stringr)     # str_detect
library(MASS)        # mvrnorm
library(spatialreg)
library(coda)        # as.mcmc HPDinterval

# ----------------------------------- #
# Setup - simulate some data
# ----------------------------------- #
x <- spacetime_sim2(phi_true = 0)
d <- x$data
w <- x$W_matrix
e <- eigen(w, only.values = TRUE)$values
# ----------------------------------- #


# ----------------------------------- #
# Estimate model
# ----------------------------------- #
m1 <- lagsarnls(y ~ x1 + x2, data = d, W = w)
summary(m1)
x$params$rho_true;
x$params$phi_true;
x$params$b_true

lw <- x$W_list
m2 <- lagsarlm(y ~ ylag + x1 + x2, data = d,
               listw = lw)

summary(m1)
summary(m2)
# ----------------------------------- #


# ----------------------------------- #
# Simulate quantities of interest
# ----------------------------------- #

# This function uses pre-estimated eigenvalues from a matrix W to very
# speedily calculate impacts of partial derivatives from a reduced-form
# spatial lag model.
impacts_e <- function(m,
                      e,
                      w        = NULL,
                      sims     = 1000,
                      cred_int = 0.95,
                      # tidy     = TRUE
                      ){

  params <- coef(m)[!str_detect(names(coef(m)), "Int|rho")]
  rho    <- coef(m)["rho"]

  nobs      <- length(e)
  tmp       <- data.frame()
  tmp_names <- apply(expand.grid(names(params),
                    c("Direct","Indirect","Total")), 1, paste, collapse=".")

  param_names <- c(names(params),"rho")

  vcv <- vcov(m)[param_names, param_names]

  for(i in 1:sims){

    # Sample coefs
    param_sim <- mvrnorm(n         = 1,
                         mu        = c(params,rho),
                         Sigma     = vcv)

    sim_rho   <- param_sim["rho"]
    sim_betas <- param_sim[!str_detect(names(param_sim), "rho")]

    # sim stuff
    direct   <- as.numeric((sim_betas * sum(1 / (1 - sim_rho * e))) / nobs)
    total    <- sim_betas/(1-sim_rho)
    indirect <- total - direct

    effs        <- c(direct, indirect, total)
    names(effs) <- tmp_names

    tmp <- bind_rows(tmp, as.data.frame(t(effs)))
  }

  # Note - use the credibility interval and median due to potential
  # for explosive draws on rho (rho>abs(1)). Median and quantile
  # mitigate impact of such draws on inference.

  tmp <- as.mcmc(tmp)
  res <- as.data.frame(HPDinterval(tmp, prob = cred_int))

  res <- res %>% mutate(median = apply(tmp, 2, median)) %>%
    relocate("median", .after = "lower")

  # a  <- (1-cred_int)/2
  # lb <- a
  # ub <- a + cred_int
  # if(tidy){
  #   res <- apply(tmp, 2, function(x){
  #     q <- quantile(x, probs = c(lb, ub))
  #     m <- median(x)
  #     r <- rbind(q[1], m, q[2])
  #     return(r)
  #   })
  #   res           <- as.data.frame(res)
  #   rownames(res) <- c(sprintf("LCI_%s", lb), "Median", sprintf("UCI_%s",ub))
  # } else{
  #   res <- tmp
  # }
  return(res)
}
# ----------------------------------- #


# ----------------------------------- #
# using "w" method:
# ----------------------------------- #
slow <- function(m, w, sims = 1000, tidy = TRUE, cred_int = 0.95){
  tmp_global <- data.frame()
  for(i in 1:sims){
    n <- nrow(w)
    params <- coef(m)[!str_detect(names(coef(m)), "Int|rho")]
    rho    <- coef(m)["rho"]
    nmes   <- c(names(params),"rho")
    vcv <- vcov(m)[nmes, nmes]
    I  <- diag(1,n)

    # Sample coefs
    param_sim <- mvrnorm(n         = 1,
                         mu        = c(params,rho),
                         Sigma     = vcv)

    sim_rho   <- param_sim["rho"]
    sim_betas <- param_sim[!str_detect(names(param_sim), "rho")]

    M <- solve(I - sim_rho * w)
    res <- lapply(sim_betas, function(x){
      bm <- x * M
      d  <- mean(diag(bm))
      tot <- sum(bm) / n
      ind <- tot - d
      return(c(d,ind,tot))
    })

    tmp_local <- as.data.frame(rbind(unlist(res)))
    tmp_global <- bind_rows(tmp_global, tmp_local)
  }

  a  <- (1-conf_int)/2
  lb <- a
  ub <- a + conf_int


  if(tidy){
    res <- apply(tmp_global, 2, function(x){
      q <- quantile(x, probs = c(lb, ub))
      m <- median(x)
      r <- rbind(q[1], m, q[2])
      return(r)
    })
    res           <- as.data.frame(res)
    rownames(res) <- c(sprintf("LCI_%s", lb), "Median", sprintf("UCI_%s",ub))
  } else{
    res <- tmp_global
  }
  return(res)
}
# ----------------------------------- #


# ----------------------------------- #
# Compare res with same sampling seed:
set.seed(123)

res1 <- impacts_e(m = m1,
                  e = e)

impacts(m2, listw = lw, R = 100)

res2 <- slow(m, w)

cat("\14");res1;res2
# ----------------------------------- #


# ----------------------------------- #
# Speed run
# ----------------------------------- #
library(microbenchmark)

mbm <- microbenchmark(
  "speedy_boi" = {impacts_e(m,e)},
  "slow_w_lad" = {slow(m,w)}
)

library(ggplot2)
autoplot(mbm)

# wow...jfc.
res <- summary(mbm)
res[2,c("min","lq","mean","median","uq","max")] /
  res[1,c("min","lq","mean","median","uq","max")]

# min of 7.6 times faster to max of 17 times.
# using eigenvalues is MUCH better....
# I could incorporate this into a bayesian model too..
# ----------------------------------- #







#-----------------------------------------------------------------------------#
# IMPACTS (via e) LRSS
#-----------------------------------------------------------------------------#

# ----------------------------------- #
rho  <- coef(m1)['rho']      # Extract spatial lag parameter from model
phi  <- coef(m1)['b_ylag']   # Extract temporal lag parameter from model
b    <- coef(m1)["b_x1"]
n    <- length(e)
Id   <- diag(1,n,n)

# VIA e - this works great!
betas    <- coef(m)[str_detect(names(coef(m)), "x")]
# direct   <- as.numeric((sim_betas * sum(1 / (1 - sim_rho * e))) / nobs)
direct   <- as.numeric((betas * sum(1 / (1 - rho * e - phi))) / nobs)
total    <- betas/(1-rho-phi)
indirect <- total - direct
effs     <- c(direct, indirect, total)
names(effs) <- apply(expand.grid(names(betas),
                                 c("Direct","Indirect","Total")), 1, paste, collapse=".")
# ----------------------------------- #



# VIA W
# Estimate Long-Run-Steady-State Multiplier Matrix
M  <- solve(Id - rho*w - phi*Id)     # LRSS_multiplier
bM <- b * M
old_dir.eff <- mean(diag(bM))
old_ind.eff <- (sum(bM) - sum(diag(bM))) / n
old_total   <- sum(bM) / n
cbind('Direct' = old_dir.eff, 'Indirect' = old_ind.eff, 'Total' = old_total)



mbm <- microbenchmark(
  "via_e" = {betas    <- coef(m)[str_detect(names(coef(m)), "x")]
  # direct   <- as.numeric((sim_betas * sum(1 / (1 - sim_rho * e))) / nobs)
  direct   <- as.numeric((betas * sum(1 / (1 - rho * e - phi))) / nobs)
  total    <- betas/(1-rho-phi)
  indirect <- total - direct
  effs     <- c(direct, indirect, total)
  names(effs) <- apply(expand.grid(names(betas),
                                   c("Direct","Indirect","Total")), 1, paste, collapse=".")
  },
  "via_w" = {M  <- solve(Id - rho*w - phi*Id)     # LRSS_multiplier
  bM <- b * M
  old_dir.eff <- mean(diag(bM))
  old_ind.eff <- (sum(bM) - sum(diag(bM))) / n
  old_total   <- sum(bM) / n
  cbind('Direct' = old_dir.eff, 'Indirect' = old_ind.eff, 'Total' = old_total)
  }
)
summary(mbm)
autoplot(mbm) + scale_y_continuous()
#-----------------------------------------------------------------------------#






#-----------------------------------------------------------------------------#
# MARGINAL RESPONSE ESTIMATION (via e)                                    ----
#-----------------------------------------------------------------------------#
e    <- eigen(w, only.values = T)$values
t    <- length(unique(d$Time))               # Number of time units
# t    <- 40 # want to see the lrss

n    <- length(unique(d$Group))
nobs <- n*t               # Now the number of observation is N x T, not N
Id   <- diag(1,nobs,nobs)

m     <- m1
rho   <- coef(m)["rho"]
phi   <- coef(m)["b_ylag"]
betas <- coef(m)[str_detect(names(coef(m)), "b_x")]

# Create the Time-Lag Generating Matrix, "L" with dimension (480 * 480):
# The first 48 rows of L are 0s.
# The last 48 cols of L are 0s.
# (480-48) * (480-48) diagonal submatrix in the lower left corner
L <- diag(nobs-n)                 # 432x432 matrix with diagonal = 1, 0 elsewhere
L <- rbind(matrix(0,n,nobs-n),L)  # Add 48 rows to top of 0s to this [first year lag]
L <- cbind(L,matrix(0,nobs,n))    # Add 48 columns to right of 0s.

el <- eigen(L, only.values = T)$values

b1 <- betas[1]
b1 * (1 / (1 - rho * e - phi * el))
tst <- as.numeric((b1 * (1 / (1 - rho * e - phi * el)))) / nobs

# AND THIS IS FUNCTIONALLY IDENTICAL:
# mean(as.numeric(b1 * (1 / (1 - rho * e - phi * el))))
# mean(diag(bM)) # 2.534079 for w-method below where bM = beta * (solve(Id - rho*W - phi*L))


wtf  <- as.numeric((b1 * (1 / (1 - rho * e - phi * el))) / nobs)
wtf2 <- t(matrix(wtf,ncol = 20, nrow = 10))




mean(bM[1,])
mean(bM[,1])

# ----------------------------------- #


# Old - via W
b1 <- betas[1]

# Estimate LRSS for Spatio-Temporal Data: -- NOTICE: "L" rather than "Id"
M  <- solve(Id - rho*w - phi*L)

# Estimate response (marginal responses)
bM <- b1 * M

# Now our marginal responses are an NT*NT matrix (480x480), we can
# adjust the column and row names to make it more understandable:

row_col_names <- paste(d$Group, d$Time, sep = "_")
# Combine each unique state name which is the state abbreviation and year.
# We will use this to label our matrices to make it easier to work with them.
colnames(bM) = rownames(bM) = row_col_names

# Now inspect top-left and bottom-right corner of response matrix:
bM[1:4, 1:4]
bM[196:200, 196:200]


# Marginal Response Uncertainty via Parametric Simulation -----------------
sims  <- 100                  # Number of simulations to run

# For lab - lowered sims from 1000 to 200 here for lab. This takes time.
# On your own time, however, 1000 would be a more appropriate number of
# simulations to run.

sim.effs <- array(data     = 0,
                  dim      = c(nobs,nobs,sims),
                  dimnames = list(row_col_names,
                                  row_col_names))

VCVM = vcov(m)[c("rho","b_ylag","b_x1"),c("rho","b_ylag","b_x1")]


for(i in 1:sims){
  if(i %in% seq(100, sims, by = 100)){
    print(sprintf('Working on iteration: %s', i))
  }

  draws <- mvrnorm(n         = 1,
                   mu        = c(rho, phi, b1),
                   Sigma     = VCVM)

  sim.rho  = draws['rho']
  sim.beta = draws['b_x1']
  sim.phi  = draws['b_ylag']

  sim.m  = solve(Id - sim.rho * w - sim.phi * L)
  sim.bm = sim.beta * sim.m

  rownames(sim.bm) = colnames(sim.bm) =  row_col_names

  sim.effs[,,i] = sim.bm
}
# Clean-up, remove unecessary objects left-over from simulation
rm(draws, sim.rho, sim.beta, sim.m, sim.bm)

# EVALUATE SIMULATION RESULTS
# NOTE - sim.effs: each ROW represents the simulated counterfactual effect in
#        that state-yr of a unit increase in "wage95" in the COLUMN state-yr

# Unit change of "b_x1" in A1 on F5 [FLQ are A neighbors]
median(sim.effs['F_5','A_1',])
hist(sim.effs['F_5','A_1',])
quantile(sim.effs['F_5','A_1',], probs = c(0.025, 0.975))

lbs <- lapply(1:10, function(x){
  quantile(sim.effs[paste0('F_',x),'A_1', ], probs = c(0.025))
}) %>% unlist()

med <- lapply(1:10, function(x){
  median(sim.effs[paste0('F_',x),'A_1', ])
}) %>% unlist()

ubs <- lapply(1:10, function(x){
  quantile(sim.effs[paste0('F_',x),'A_1', ], probs = c(0.975))
}) %>% unlist()


plt_dat <- data.frame(
  x  = 1:10,
  y  = med,
  lb = lbs,
  ub = ubs
)

ggplot(data = plt_dat, aes(x = x, y = y)) +
  geom_ribbon(aes(ymin = lb, ymax = ub, fill = "95% HPD"), alpha = 0.6) +
  geom_line() +
  labs(x = "Time", y = "Response, F", title = "Response in F to shock of X1 in A at time 1") +
  theme_bw()

#-----------------------------------------------------------------------------#



















#-----------------------------------------------------------------------------#
# other
#-----------------------------------------------------------------------------#
# eigenw()
# eigen_pre_setup()
# eigen_setup()

# spatialreg::impacts.sarlm
# View(spatialreg::impacts.sarlm)
# view(spatialreg:::intImpacts)
# View(spatialreg:::intImpacts)
# View(spatialreg:::lagImpacts_e)
# View(spatialreg:::lagImpacts_e)
# View(spatialreg:::intImpacts)
# View(spatialreg::impacts.sarlm)
#-----------------------------------------------------------------------------#
# my first pass... so close yet so far
# rho <- coef(m)['rho']
# n  <- nrow(w)
# Id <- diag(1, n, n)
# M  <- solve(Id - rho * w)
# M2 <- solve(Id - rho * e)
#-----------------------------------------------------------------------------#
